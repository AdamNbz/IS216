package lab2.inclass.p2c3;
import java.util.*;

/*
 *
 *  author: CacAnhDaDen (nbzzz, Hinno, _qnk_)
 *
 */

public abstract class Robot {
    protected double M;
    protected double S = 10;
    
    public abstract double tinhTieuThu();
    public abstract void display();
}
