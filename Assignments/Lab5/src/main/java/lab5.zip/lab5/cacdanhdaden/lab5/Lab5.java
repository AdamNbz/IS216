package cacdanhdaden.lab5;
import view_ques1.*;
import view_ques2.*;

/*
 *
 *  author: CacAnhDaDen (nbzzz, Hinno, _qnk_)
 *
 */

public class Lab5 {
    public static void main(String[] args) {
        Selection s = new Selection();
    }
}
