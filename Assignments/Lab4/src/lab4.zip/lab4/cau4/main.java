package lab4.cau4;

/*
 *
 *  author: CacAnhDaDen (nbzzz, Hinno, _qnk_)
 *
 */

public class main {
    public static void main(String[] args)
    {
        new BookManager();
    }
}
