package lab4.cau1;

/*
 *
 *  author: CacAnhDaDen (nbzzz, Hinno, _qnk_)
 *
 */

public class main {
    public static void main(String[] args) {
        new Calculator();
    }
    
}
